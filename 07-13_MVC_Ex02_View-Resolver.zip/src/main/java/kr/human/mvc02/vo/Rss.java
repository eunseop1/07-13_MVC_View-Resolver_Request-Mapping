package kr.human.mvc02.vo;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@XmlRootElement
@Data
public class Rss {//RssVO로 했었지만, 사이트 태그가 Rss이므로 이름 변경
	private Channel channel;
	
	@Data
	@XmlRootElement
	public static class Channel{
		private String title;
		private String link;
		private String description;
		private List<Item> item;
		
	}
	
	@Data
	@XmlRootElement
	public static class Item{ // News 한개
		private String title;
		private String link;
		private String description;
		private String author;
		private String pubDate;
		private String image;
	}
}
