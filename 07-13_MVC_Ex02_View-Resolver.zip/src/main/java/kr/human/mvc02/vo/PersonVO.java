package kr.human.mvc02.vo;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@XmlRootElement(name="person") //루트 태그 이름 작성 가능
//이걸 적으면 xml을 기본으로 나오고, 안붙여주면 json을 기본으로 나온다
@XmlType(propOrder = {"name", "gender", "birth"}) //태그가 나타나는 순서
@XmlAccessorType(XmlAccessType.FIELD)
public class PersonVO {
	
	@XmlElement // 태그로 쓴다
	private String name;
	
	@XmlAttribute //속성으로 쓰겠다
	private int age;
	
	@XmlElement
	@XmlJavaTypeAdapter(GenderAdapter.class)
// XML로 만들때와 객체로 읽을때 모양 지정할수 있다 -> 무조건 클래스 타입이어야 한다
	private Boolean gender;
	
	@XmlElement
	@XmlJavaTypeAdapter(BirthAdapter.class)
	private Date birth;
}
