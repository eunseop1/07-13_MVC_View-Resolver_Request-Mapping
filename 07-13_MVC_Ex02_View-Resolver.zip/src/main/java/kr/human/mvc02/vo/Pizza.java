package kr.human.mvc02.vo;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import lombok.Data;
import lombok.NoArgsConstructor;

@XmlRootElement(name = "pizza")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {"name","flavor","toppings"})
@Data
@NoArgsConstructor
public class Pizza {
	@XmlElement
	private String name;

	@XmlElement
	private String flavor;

	@XmlElement
	private List<String> toppings = new ArrayList<String>();

	public Pizza(String name) {
		this.name = name;
		this.flavor = "spicy";
		this.toppings.add("Cheese");
		this.toppings.add("bakon");
	}
/*
	@XmlElement // Name이 태그가 된다
	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	@XmlElement // Flavor이 태그가 된다
	public void setFlavor(String flavor) {
		this.flavor = flavor;
	}

	public String getFlavor() {
		return flavor;
	}

	public List<String> getToppings() {
		return toppings;
	}

	@XmlElement // Toppings가 태그가 된다
	public void setToppings(List<String> toppings) {
		this.toppings = toppings;
	}
*/
}